Deletions:
	[/highlights.config]
	No object highlight on hover
	
	[/player/stat_primary.animation.patch]
	No player glow (except for Novakids)

Modifications:
	[/cinematics/splash.cinematic]
	Splash screen: you can now set your own image by replacing the "hi.png" file
	
	[/playermodes.config]
	Player modes improvement:
		Casual: no money cost on death
		Survival: no material and liquid drop, can always beam up
		Hardcore: no permadeath, revive costs all money
	
	[/itemdrop.config]
	Item drop [Q] becomes item yeet instead!
	
	[/interface/windowconfig/playerinventory.config]
	New item pick/put sounds, no item recycle cooldown

Additions:
	[/ships/...]
	Player ships now have (and set to) a custom tilemap
